import React from 'react';
import './index.scss';
import { Input } from 'antd';
import { UserOutlined, ShoppingCartOutlined, SearchOutlined } from '@ant-design/icons';

export default function BasicLayout(params = { children: {} }) {
  return (
    <section className='basic-layout'>
      <div className='header'>
        <div className='caption' style={{ cursor: "pointer" }} onClick={() => {
          console.log("this====", params);
          // this.props.history.push("/");
          window.location.href = ("#/")
        }}>
          <div className='text1'>Management</div>
          <div className='text2'>Chuwa</div>
        </div>
        <Input size="small" style={{ height: "40px", width: "300px", marginLeft: "20px" }} placeholder="Search" suffix={<SearchOutlined />} />
        <div className='right'>
          <UserOutlined style={{ color: "#fff", marginLeft: "20px" }} /><span style={{ marginLeft: "10px", cursor: "pointer" }} onClick={() => {
            console.log("this====", params);
            // this.props.history.push("/login");
            window.location.href = ("#/login")
          }}>Sign In</span>
          <span style={{ cursor:"pointer" }}  onClick={() => {
            console.log("this====", params);
            // this.props.history.push("/login");
            window.location.href = ("#/car")
          }}>
            <ShoppingCartOutlined style={{ color: "#fff", marginLeft: "20px" }} /><span style={{ marginLeft: "10px" }}></span>
          </span>
        </div>
      </div>
      <div className='basic-layout-content'>
        {params.children}
      </div>

      <div className='footer'>
        <div className='caption'>
          ©2022 All Rights Reserved.
        </div>
        <div className='right'>
          <span className='item'>
            Contact us
          </span>
          <span className='item'>
            Privacy Policies
          </span>
          <span className='item'>
            Help
          </span>
        </div>

      </div>
    </section>
  );
}
